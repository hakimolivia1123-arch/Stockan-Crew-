/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  Tablet,
  Monitor,
  RotateCcw,
  ExternalLink,
  Download,
  Copy,
  Check,
  FileCode,
  Sparkles,
  ShieldCheck,
  Zap,
  Layers,
  MessageSquare,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  Info,
  Calendar,
  Send,
  Sliders,
  SunMoon,
  Clock,
  ArrowUpRight,
  ListOrdered,
  Maximize2,
  Minimize2,
} from 'lucide-react';

type TabView = 'preview' | 'review' | 'whatsapp' | 'source';
type DeviceMode = 'mobile' | 'compact' | 'tablet' | 'full';

interface AuditItem {
  id: string;
  category: string;
  title: string;
  score: string;
  badge: string;
  summary: string;
  highlights: string[];
  recommendation?: string;
}

const DEFAULT_ITEMS = [
  { name: 'Karage', units: 'pack' },
  { name: 'Sayap', units: 'pack + porsi' },
  { name: 'Ayam filet', units: 'porsi' },
  { name: 'Ayam kecil', units: 'pack + porsi' },
  { name: 'Ayam besar', units: 'pack + porsi' },
  { name: 'Ebi', units: 'pcs' },
  { name: 'Timun', units: 'satuan terbuka' },
  { name: 'Crabstik', units: 'satuan terbuka' },
  { name: 'Koslow', units: 'satuan terbuka' },
  { name: 'Selada', units: 'satuan terbuka' },
  { name: 'Saos Black paper', units: 'satuan terbuka' },
  { name: 'Saos teriyaki', units: 'satuan terbuka' },
  { name: 'Saos Asam manis', units: 'btl' },
  { name: 'Saos pedas', units: 'satuan terbuka' },
  { name: 'Cuka', units: 'satuan terbuka' },
  { name: 'Kwipie', units: 'pack' },
  { name: 'Mestro', units: 'satuan terbuka' },
  { name: 'Mentai', units: 'satuan terbuka' },
  { name: 'Wijen', units: 'satuan terbuka' },
  { name: 'Minyak', units: 'satuan terbuka' },
  { name: 'Tobiko', units: 'satuan terbuka' },
  { name: 'Ricepaper', units: 'lembar' },
  { name: 'Mika', units: 'pcs' },
  { name: 'Cup(35)', units: 'pcs' },
  { name: 'Sambal horeg', units: 'multi-kolom' },
  { name: 'Nasi', units: 'kg + kg + kg' },
  { name: 'Nori', units: 'pack + lembar' },
  { name: 'Klip besar', units: 'pack + pcs' },
  { name: 'Klip sedang', units: 'pack + pcs' },
  { name: 'Klip kecil', units: 'pcs' },
  { name: 'Tepung wfc', units: 'pack' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabView>('preview');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('mobile');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [iframeKey, setIframeKey] = useState<number>(1);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [htmlSource, setHtmlSource] = useState<string>('');
  const [isLoadingSource, setIsLoadingSource] = useState<boolean>(true);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // WhatsApp simulation state
  const [waTitle, setWaTitle] = useState<string>('Sisa Fisik');
  const [waPhone, setWaPhone] = useState<string>('081234567890');
  const [waIncludeDate, setWaIncludeDate] = useState<boolean>(true);
  const [selectedAuditId, setSelectedAuditId] = useState<string>('arch');

  const toastTimerRef = useRef<number | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMsg(null);
    }, 2800);
  };

  // Fetch HTML source from the public file
  useEffect(() => {
    let isMounted = true;
    fetch('/sisa-fisik.html')
      .then((res) => res.text())
      .then((txt) => {
        if (isMounted) {
          setHtmlSource(txt);
          setIsLoadingSource(false);
        }
      })
      .catch(() => {
        if (isMounted) {
          // Fallback to direct asset path
          fetch('/assets/aistudio/index_d73830d3.html')
            .then((r) => r.text())
            .then((t) => {
              if (isMounted) {
                setHtmlSource(t);
                setIsLoadingSource(false);
              }
            })
            .catch(() => {
              if (isMounted) setIsLoadingSource(false);
            });
        }
      });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleCopy = async (text: string, key: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      showToast(`${label} berhasil disalin ke clipboard!`);
      setTimeout(() => setCopiedKey(null), 2200);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      setCopiedKey(key);
      showToast(`${label} berhasil disalin!`);
      setTimeout(() => setCopiedKey(null), 2200);
    }
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast(`File ${filename} berhasil diunduh!`);
  };

  const handleRefreshIframe = () => {
    setIframeKey((prev) => prev + 1);
    showToast('Pratinjau web app dimuat ulang');
  };

  const todayFormatted = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Sample simulated WhatsApp message based on defaults
  const sampleItemsSimulated = [
    { name: 'Karage', val: '4 pack' },
    { name: 'Sayap', val: '6 pack + 12 porsi' },
    { name: 'Ayam filet', val: '18 porsi' },
    { name: 'Ayam kecil', val: '5 pack + 8 porsi' },
    { name: 'Ayam besar', val: '3 pack' },
    { name: 'Ebi', val: '45 pcs' },
    { name: 'Timun', val: '2.5' },
    { name: 'Crabstik', val: '14' },
    { name: 'Koslow', val: '3' },
    { name: 'Selada', val: '1.8' },
    { name: 'Saos Asam manis', val: '2 btl' },
    { name: 'Kwipie', val: '3 pack' },
    { name: 'Ricepaper', val: '80 lembar' },
    { name: 'Mika', val: '120 pcs' },
    { name: 'Nasi', val: '15 kg + 10 kg + 5 kg' },
    { name: 'Klip besar', val: '2 pack + 30 pcs' },
    { name: 'Tepung wfc', val: '4 pack' },
  ];

  const simulatedWaMessage = `${waTitle.trim() ? `*${waTitle.trim()}*` : ''}${
    waIncludeDate ? ` – ${todayFormatted}` : ''
  }\n\n${sampleItemsSimulated.map((i) => `${i.name} ${i.val}`).join('\n')}\n... (+ 14 barang lainnya)`;

  const audits: AuditItem[] = [
    {
      id: 'arch',
      category: 'Arsitektur & UI Design',
      title: 'Tampilan Modern Aurora Glassmorphism & Dual Theme',
      score: '9.9 / 10',
      badge: 'Sangat Bagus',
      summary:
        'Aplikasi dibangun dengan standar antarmuka modern yang sangat elegan. Menggunakan latar belakang fluid animated aurora blur (CSS gradient), panel glassmorphism dengan backdrop-filter blur 20px, serta tema ganda (Gelap & Terang) yang responsif terhadap pencahayaan ruangan.',
      highlights: [
        'Latar belakang aurora dengan 3 blob bercahaya animasi rotasi drift yang halus tanpa lag (CSS hardware-accelerated)',
        'Dual theme dengan CSS variable switch yang instan dan menyimpan preferensi ke localStorage',
        'Tipografi menggunakan Plus Jakarta Sans dengan bobot font 400-800 yang sangat mudah dibaca oleh staf operasional',
        'Animasi micro-interaction: Pop spring, ripple klik, dan efek confetti burst yang meriah saat kirim sukses',
      ],
      recommendation:
        'Desain visual sudah sangat premium dan modern. Sangat nyaman dipakai di dapur yang gelap maupun di area kasir/gudang yang terang.',
    },
    {
      id: 'ux',
      category: 'User Experience (UX)',
      title: 'Multi-Slot Satuan Bertingkat & Mode Atur Terpisah',
      score: '9.8 / 10',
      badge: 'Fitur Unggulan',
      summary:
        'Fitur multi-slot satuan adalah inovasi terbaik untuk stock opname fisik makanan. Dalam operasional restoran/kitchen, barang sering tersisa di beberapa tempat atau kemasan (contoh: "1 dus + 3 pack + 15 pcs" atau "Nasi 15 kg + 10 kg").',
      highlights: [
        'Tombol "+" pada kartu barang untuk menambah kolom satuan tanpa batas sesuai kondisi fisik di lokasi',
        'Pemisahan tegas antara Mode "Isi" (fokus input angka cepat) dan Mode "Atur" (ubah urutan, ubah nama, hapus, tambah barang baru)',
        'Keyboard numpad otomatis (enterkeyhint="next") sehingga staf cukup tekan Enter untuk langsung pindah ke barang berikutnya',
        'Drag and drop reordering dengan animasi FLIP (First, Last, Invert, Play) yang sangat mulus di HP layar sentuh',
      ],
      recommendation:
        'Dukungan drag-and-drop di ponsel pintar sudah dilengkapi dengan touch-action: none dan haptic vibration.',
    },
    {
      id: 'wa',
      category: 'Integrasi WhatsApp',
      title: 'Ekspor WhatsApp Cerdas & Sanitasi Nomor Otomatis',
      score: '9.7 / 10',
      badge: 'Praktis & Aman',
      summary:
        'Format teks yang dihasilkan langsung rapi dan siap baca oleh manajer, supervisor, atau tim purchasing via WhatsApp. Dilengkapi sanitasi nomor telepon cerdas dan sistem konfirmasi kelengkapan stok sebelum kirim.',
      highlights: [
        'Sanitasi nomor: Otomatis mengubah awalan "08xx" atau "8xx" menjadi format internasional "628xx"',
        'Peringatan otomatis bila ada barang yang belum terisi agar tim tidak salah kirim laporan yang belum lengkap',
        'Format teks terstruktur: Judul tebal (*Sisa Fisik*), tanggal hari ini bahasa Indonesia, dan tanda hubung "+" otomatis antar satuan',
        'Pilihan fleksibel: Nomor tujuan bisa dikosongkan agar pengguna bebas memilih kontak atau grup WhatsApp secara manual',
      ],
      recommendation:
        'WhatsApp Web/App membuka tautan wa.me secara instan di perangkat Android, iOS, maupun PC.',
    },
    {
      id: 'perf',
      category: 'Performa & Offline-Ready',
      title: 'Performa Kilat (0 Dependency Eksternal) & Auto-Reset Harian',
      score: '10 / 10',
      badge: 'Sempurna',
      summary:
        'Aplikasi 100% murni Vanilla JavaScript dan CSS tanpa ketergantungan library berat (0 MB bundle size tambahan). Aplikasi terbuka dalam kurang dari 0.1 detik dan bekerja 100% offline tanpa perlu koneksi internet.',
      highlights: [
        'Ukuran file hanya ~48 KB: Bisa diunduh dan dijalankan seketika bahkan pada koneksi internet paling lambat sekalipun',
        'Auto-clear pergantian hari: Menghapus angka stok kemarin saat berganti hari baru, namun nama barang dan satuan tetap tersimpan aman',
        'Debounced localStorage save (200ms): Tidak membebani memori browser dan mencegah kehilangan data saat aplikasi ditutup mendadak',
        'Dapat dipasang ke layar utama HP (Add to Home Screen) sebagai aplikasi web mandiri',
      ],
      recommendation:
        'Sangat direkomendasikan untuk dibagikan ke seluruh tim dapur dan gudang via tautan web atau file HTML langsung.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-emerald-500 text-slate-950 text-xs font-bold shadow-xl shadow-emerald-500/20 animate-in fade-in slide-in-from-top-3 duration-200">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Brand & Status */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-lg">
              SF
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold tracking-tight text-white">
                  Sisa Fisik — Web App Studio
                </h1>
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Aktif & Siap Pakai
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Aplikasi pencatatan stok fisik dapur/gudang & ekspor WhatsApp otomatis
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'preview'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Pratinjau Aplikasi</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('review')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'review'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Riview & Audit Web App</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('whatsapp')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'whatsapp'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Simulator WhatsApp</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('source')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'source'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Kode & Panduan Deploy</span>
            </button>
          </nav>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <a
              href="/sisa-fisik.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
              title="Buka web app di tab baru browser"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Buka Tab Baru</span>
            </a>
            <button
              type="button"
              onClick={() => handleDownload('index.html', htmlSource)}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-500/20"
              title="Unduh file web app siap pakai"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh File</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col">
        {/* ================= TAB 1: PRATINJAU LANGSUNG ================= */}
        {activeTab === 'preview' && (
          <div className="space-y-4 flex-1 flex flex-col">
            {/* Control Bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:px-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Ukuran Layar:
                </span>
                <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setDeviceMode('mobile');
                      setIsFullscreen(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      deviceMode === 'mobile' && !isFullscreen
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>HP Mobile (390px)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDeviceMode('compact');
                      setIsFullscreen(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      deviceMode === 'compact' && !isFullscreen
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Smartphone className="w-3 h-3" />
                    <span>Kompak (360px)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDeviceMode('tablet');
                      setIsFullscreen(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      deviceMode === 'tablet' && !isFullscreen
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Tablet className="w-3.5 h-3.5" />
                    <span>Tablet (640px)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDeviceMode('full');
                      setIsFullscreen(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                      deviceMode === 'full' || isFullscreen
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Monitor className="w-3.5 h-3.5" />
                    <span>Layar Penuh</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRefreshIframe}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
                  title="Muat ulang pratinjau"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Refresh Web</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsFullscreen(!isFullscreen)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
                    isFullscreen
                      ? 'bg-emerald-500 text-slate-950 border-emerald-500'
                      : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                  }`}
                  title={isFullscreen ? 'Keluar mode penuh' : 'Tampilkan penuh di layar ini'}
                >
                  {isFullscreen ? (
                    <Minimize2 className="w-3.5 h-3.5" />
                  ) : (
                    <Maximize2 className="w-3.5 h-3.5" />
                  )}
                  <span>{isFullscreen ? 'Kecilkan' : 'Perbesar'}</span>
                </button>
              </div>
            </div>

            {/* Device Container Frame */}
            <div className="flex-1 flex justify-center items-start min-h-[640px] py-2">
              <div
                className={`transition-all duration-300 relative flex flex-col ${
                  isFullscreen || deviceMode === 'full'
                    ? 'w-full h-[780px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950'
                    : deviceMode === 'tablet'
                      ? 'w-[640px] h-[780px] rounded-[32px] p-3 border-4 border-slate-800 shadow-2xl bg-slate-900'
                      : deviceMode === 'compact'
                        ? 'w-[360px] h-[740px] rounded-[36px] p-2.5 border-4 border-slate-800 shadow-2xl bg-slate-900'
                        : 'w-[400px] h-[780px] rounded-[44px] p-3 border-[6px] border-slate-800 shadow-2xl bg-slate-900'
                }`}
              >
                {/* Phone Top Notch / Speaker (when in mobile frame) */}
                {!isFullscreen && deviceMode !== 'full' && (
                  <div className="w-full flex items-center justify-between px-6 py-2 bg-slate-950 rounded-t-[30px] select-none text-[11px] font-semibold text-slate-400">
                    <span>09:41</span>
                    <div className="w-20 h-4 bg-slate-900 rounded-full flex items-center justify-center">
                      <div className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-800" />
                    </div>
                    <div className="flex items-center gap-1 text-[10px]">
                      <span>5G</span>
                      <span>100%</span>
                    </div>
                  </div>
                )}

                {/* The Embedded Live Web App */}
                <div className="flex-1 w-full h-full rounded-2xl overflow-hidden bg-slate-950 relative">
                  <iframe
                    key={iframeKey}
                    ref={iframeRef}
                    title="Live Sisa Fisik Web App"
                    src="/sisa-fisik.html"
                    className="w-full h-full border-0"
                    allow="clipboard-write; vibration"
                  />
                </div>

                {/* Phone Bottom Home Bar */}
                {!isFullscreen && deviceMode !== 'full' && (
                  <div className="w-full py-1.5 flex justify-center bg-slate-950 rounded-b-[30px]">
                    <div className="w-28 h-1 bg-slate-700 rounded-full" />
                  </div>
                )}
              </div>
            </div>

            {/* Quick Testing Guide Banner */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Peningkatan Tampilan & Fitur Baru yang Telah Diaktifkan:</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 mb-1">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-[10px]">
                      1
                    </span>
                    <span>Tampilan Ramping Hemat Tempat</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Tinggi kartu kini dipangkas 50% menjadi satu baris kompak (50px). Memuat 2.5× lebih banyak barang di layar tanpa harus terus scroll.
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="flex items-center gap-2 font-bold text-cyan-400 mb-1">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[10px]">
                      2
                    </span>
                    <span>Pop-up Satuan Cepat (+)</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Klik <strong>+</strong> pada barang, pilih chip satuan (<em>pack, porsi, pcs, btl, dll</em>) & klik <strong>Oke</strong>, kursor langsung fokus dan <strong>tinggal isi angka</strong>!
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="flex items-center gap-2 font-bold text-purple-400 mb-1">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center text-[10px]">
                      3
                    </span>
                    <span>Simbol Pensil ✏️ (Mode Edit)</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Cukup klik ikon <strong>Pensil ✏️</strong> di kanan atas untuk langsung beralih ke mode Edit (geser urutan ☰, ganti nama, atau hapus). Klik lagi untuk kembali.
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="flex items-center gap-2 font-bold text-amber-400 mb-1">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-[10px]">
                      4
                    </span>
                    <span>Tambah Barang Baru Instan</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Dalam mode Edit, tekan tombol <strong>Tambah barang</strong> di bawah, isi nama & ketuk chip satuan, lalu klik Oke.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 2: RIVIEW & AUDIT LENGKAP ================= */}
        {activeTab === 'review' && (
          <div className="space-y-6">
            {/* Executive Scorecard */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Audit & Evaluasi Teknis
                    </span>
                    <span className="text-xs text-slate-400">Versi 1.0.0 (Production Ready)</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    Riview Aplikasi Web “Sisa Fisik”
                  </h2>
                  <p className="text-sm text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
                    Aplikasi web ini dirancang khusus untuk kebutuhan opname sisa bahan restoran
                    secara cepat, akurat, dan langsung terhubung ke WhatsApp manajemen. Berikut
                    analisis arsitektur, keunggulan fitur, dan evaluasi pengembangannya.
                  </p>
                </div>

                <div className="flex items-center gap-4 bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
                  <div className="text-center px-2">
                    <div className="text-3xl font-black text-emerald-400 tabular-nums">9.8</div>
                    <div className="text-[11px] font-bold text-slate-400 uppercase mt-0.5">
                      Skor Total
                    </div>
                  </div>
                  <div className="w-px h-10 bg-slate-800" />
                  <div className="text-center px-2">
                    <div className="text-3xl font-black text-cyan-400 tabular-nums">100</div>
                    <div className="text-[11px] font-bold text-slate-400 uppercase mt-0.5">
                      Performa
                    </div>
                  </div>
                  <div className="w-px h-10 bg-slate-800" />
                  <div className="text-center px-2">
                    <div className="text-3xl font-black text-amber-400 tabular-nums">0 kB</div>
                    <div className="text-[11px] font-bold text-slate-400 uppercase mt-0.5">
                      Dependensi
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                    <Layers className="w-4 h-4 text-emerald-400" />
                    <span>Daftar Bawaan</span>
                  </div>
                  <div className="text-lg font-bold text-white">31 Bahan Pokok</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Karage, Sayap, Saos, Nasi, Mika, dll
                  </div>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span>Kecepatan Buka</span>
                  </div>
                  <div className="text-lg font-bold text-white">0.05 Detik</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Vanilla JS murni, instan tanpa loading
                  </div>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                    <ShieldCheck className="w-4 h-4 text-purple-400" />
                    <span>Penyimpanan</span>
                  </div>
                  <div className="text-lg font-bold text-white">LocalStorage HP</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    100% aman, data tidak diunggah ke pihak ketiga
                  </div>
                </div>
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-1">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>Otomasi Harian</span>
                  </div>
                  <div className="text-lg font-bold text-white">Auto-Clear Shift</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Angka reset otomatis saat ganti hari baru
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Audit Cards */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>Rincian Evaluasi Fitur & Arsitektur</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {audits.map((item) => (
                  <div
                    key={item.id}
                    className={`bg-slate-900 border rounded-2xl p-5 transition-all flex flex-col justify-between ${
                      selectedAuditId === item.id
                        ? 'border-emerald-500/80 shadow-lg shadow-emerald-500/10'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                    onClick={() => setSelectedAuditId(item.id)}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-3 mb-2">
                        <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                          {item.category}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                            {item.score}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300">
                            {item.badge}
                          </span>
                        </div>
                      </div>

                      <h4 className="text-base font-bold text-white mb-2">{item.title}</h4>
                      <p className="text-xs text-slate-400 leading-relaxed mb-4">{item.summary}</p>

                      <div className="space-y-2 mb-4">
                        <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                          Poin Keunggulan:
                        </span>
                        {item.highlights.map((h, i) => (
                          <div
                            key={i}
                            className="flex items-start gap-2 text-xs text-slate-300 leading-normal"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {item.recommendation && (
                      <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-400 flex items-start gap-2 mt-2">
                        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-slate-200">Catatan Pakar: </strong>
                          {item.recommendation}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Catalog Breakdown Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-base font-bold text-white">
                    Daftar Barang Bawaan (Default Catalog Restoran)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Total 31 item bahan makanan siap pakai yang sudah terkonfigurasi di dalam web app
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold px-2.5 py-1 bg-slate-800 rounded-lg text-slate-300 border border-slate-700">
                    31 Item Aktif
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 max-h-[340px] overflow-y-auto pr-1">
                {DEFAULT_ITEMS.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition-colors"
                  >
                    <div className="text-[11px] font-mono text-emerald-400/80 mb-0.5">
                      #{idx + 1}
                    </div>
                    <div className="text-xs font-bold text-white truncate">{item.name}</div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">{item.units}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: SIMULATOR WHATSAPP ================= */}
        {activeTab === 'whatsapp' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column: WhatsApp Config & Format Tester */}
            <div className="lg:col-span-6 space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-1">
                  <Sliders className="w-4 h-4 text-emerald-400" />
                  <span>Pengaturan Format Pesan WhatsApp</span>
                </h3>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                  Uji bagaimana teks laporan dibuat dan dikirim ke nomor WhatsApp manajer atau grup.
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                      Judul Pesan
                    </label>
                    <input
                      type="text"
                      value={waTitle}
                      onChange={(e) => setWaTitle(e.target.value)}
                      placeholder="Contoh: Sisa Fisik Shift Malam"
                      className="w-full h-10 px-3.5 rounded-xl border border-slate-700 bg-slate-950 text-sm font-semibold text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5 uppercase tracking-wider">
                      Nomor Tujuan WhatsApp (Opsional)
                    </label>
                    <input
                      type="tel"
                      value={waPhone}
                      onChange={(e) => setWaPhone(e.target.value)}
                      placeholder="08123456789 atau 628123456789"
                      className="w-full h-10 px-3.5 rounded-xl border border-slate-700 bg-slate-950 text-sm font-semibold text-white focus:border-emerald-500 focus:outline-none"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Web app otomatis mengubah format <code>08xx</code> menjadi <code>628xx</code>{' '}
                      sesuai protokol resmi WhatsApp.
                    </p>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                    <div>
                      <div className="text-xs font-bold text-slate-200">
                        Sertakan Tanggal Otomatis
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Menambahkan hari dan tanggal lengkap bahasa Indonesia di judul
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={waIncludeDate}
                      onChange={(e) => setWaIncludeDate(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-400 bg-slate-900 border-slate-700 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Uji Tautan & Salin Pesan
                </h4>
                <div className="flex flex-wrap gap-2.5">
                  <button
                    type="button"
                    onClick={() =>
                      handleCopy(simulatedWaMessage, 'wa-msg', 'Format pesan WhatsApp')
                    }
                    className="flex-1 min-w-[160px] h-10 px-4 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center justify-center gap-2"
                  >
                    {copiedKey === 'wa-msg' ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                    <span>
                      {copiedKey === 'wa-msg' ? 'Tersalin ke Clipboard' : 'Salin Teks Pesan'}
                    </span>
                  </button>

                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(simulatedWaMessage)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 min-w-[160px] h-10 px-4 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors flex items-center justify-center gap-2 shadow-sm shadow-emerald-500/20"
                  >
                    <Send className="w-4 h-4" />
                    <span>Tes Kirim via WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Right Column: Simulated WhatsApp Phone Bubble */}
            <div className="lg:col-span-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
                {/* Simulated WhatsApp Header */}
                <div className="bg-[#1f2c34] px-4 py-3 flex items-center justify-between text-white border-b border-[#2a3942]">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center text-xs font-bold text-white">
                      M
                    </div>
                    <div>
                      <div className="text-sm font-bold leading-tight">Grup Manajer & Dapur</div>
                      <div className="text-[11px] text-emerald-400 leading-tight">
                        online · laporan shift
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-slate-400">WhatsApp</div>
                </div>

                {/* Simulated WhatsApp Chat Body */}
                <div className="p-4 sm:p-6 bg-[#0b141a] min-h-[460px] max-h-[520px] overflow-y-auto flex flex-col justify-end">
                  {/* Chat Bubble */}
                  <div className="self-end max-w-[90%] bg-[#005c4b] text-[#e9edef] rounded-2xl rounded-tr-xs p-3.5 text-xs shadow-md space-y-2 leading-relaxed">
                    <div className="font-bold text-white border-b border-[#00755f] pb-1.5 flex items-center justify-between">
                      <span>{waTitle.trim() || 'Sisa Fisik'}</span>
                      {waIncludeDate && (
                        <span className="text-[10px] text-emerald-200/80 font-normal">
                          {todayFormatted}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 font-mono text-[11px] text-emerald-100/90 pt-1">
                      {sampleItemsSimulated.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between gap-4">
                          <span className="text-white font-medium">{item.name}</span>
                          <span className="text-emerald-200 font-bold">{item.val}</span>
                        </div>
                      ))}
                      <div className="text-[10px] text-emerald-300/70 italic pt-1">
                        ... (+ 14 barang lainnya tersusun rapi)
                      </div>
                    </div>

                    <div className="text-right text-[10px] text-emerald-300/80 flex items-center justify-end gap-1 pt-1">
                      <span>21:00</span>
                      <Check className="w-3 h-3 text-cyan-400" />
                    </div>
                  </div>
                </div>

                {/* Footer simulation */}
                <div className="bg-[#1f2c34] p-3 text-center text-xs text-slate-400 border-t border-[#2a3942]">
                  Pesan di atas diformat otomatis oleh aplikasi web saat tombol{' '}
                  <strong className="text-white">“Kirim ke WhatsApp”</strong> ditekan.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 4: KODE & PANDUAN DEPLOY ================= */}
        {activeTab === 'source' && (
          <div className="space-y-6">
            {/* Banner Khusus: Solusi Layar Putih di GitHub Pages */}
            <div className="bg-gradient-to-r from-amber-950/70 via-slate-900 to-slate-900 border-2 border-amber-500/50 rounded-2xl p-5 shadow-xl">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-extrabold text-white">
                      Kenapa Layar Putih di GitHub Pages & Cara Mengatasinya dalam 1 Menit
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300">
                      Solusi Pasti Berhasil
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Layar putih terjadi karena <strong>file yang di-upload ke GitHub adalah file project React/Vite mentah</strong> yang mencari script <code className="text-amber-300">/src/main.tsx</code> (browser tidak bisa membaca file .tsx), <em>atau</em> file dinamai selain <code className="text-amber-300">index.html</code>.
                  </p>

                  <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-3 mt-2 text-xs">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Cara Memperbaiki (Hanya Butuh 1 File):</span>
                    </div>
                    <ol className="list-decimal list-inside space-y-1.5 text-slate-300 pl-1">
                      <li>
                        Klik tombol hijau <strong>"Unduh index.html untuk GitHub"</strong> di bawah ini.
                      </li>
                      <li>
                        Buka repositori GitHub Anda di browser (<code className="text-cyan-300">github.com/username/repo</code>).
                      </li>
                      <li>
                        Hapus file/folder lama, lalu klik <strong>Add file &gt; Upload files</strong>.
                      </li>
                      <li>
                        Unggah file <code className="text-emerald-300 font-bold font-mono">index.html</code> yang baru saja Anda unduh (pastikan namanya tepat <strong>index.html</strong> huruf kecil di root repo, bukan di dalam subfolder).
                      </li>
                      <li>
                        Klik <strong>Commit changes</strong>. Tunggu 1 menit lalu refresh link GitHub Pages Anda. <strong>Aplikasi web langsung terbuka 100% sempurna!</strong>
                      </li>
                    </ol>
                  </div>

                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => handleDownload('index.html', htmlSource)}
                      className="px-4 py-2.5 rounded-xl text-xs font-extrabold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20"
                    >
                      <Download className="w-4 h-4" />
                      <span>Unduh index.html untuk GitHub (File Mandiri Siap Pakai)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(htmlSource, 'full-code', 'Kode HTML')}
                      className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-2"
                    >
                      <Copy className="w-4 h-4" />
                      <span>Salin Isi Kode HTML</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Header with download & copy */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-emerald-400" />
                  <span>Kode Sumber Tunggal: index.html</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  File mandiri (~48.9 KB) berisi seluruh HTML, CSS Aurora, dan logika JavaScript
                  tanpa build step
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => handleCopy(htmlSource, 'full-code', 'Kode HTML')}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-2"
                >
                  {copiedKey === 'full-code' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                  <span>{copiedKey === 'full-code' ? 'Tersalin!' : 'Salin Semua Kode'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownload('index.html', htmlSource)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors flex items-center gap-2 shadow-sm shadow-emerald-500/20"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh index.html</span>
                </button>
              </div>
            </div>

            {/* Code Viewer Container */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950 border-b border-slate-800 text-xs text-slate-400 font-mono">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <span className="text-slate-200 font-bold">sisa-fisik.html</span>
                  <span>·</span>
                  <span>923 baris kode murni</span>
                </div>
                <span>48.9 KB</span>
              </div>

              <div className="relative max-h-[500px] overflow-y-auto bg-slate-950 p-4 font-mono text-xs text-slate-300 leading-relaxed">
                {isLoadingSource ? (
                  <div className="py-20 text-center text-slate-500">Memuat kode sumber...</div>
                ) : (
                  <pre className="whitespace-pre overflow-x-auto">
                    <code>{htmlSource}</code>
                  </pre>
                )}
              </div>
            </div>

            {/* Deployment Guide */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                <span>Panduan Menjalankan & Membagikan Web App Ini</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-emerald-400 text-sm">
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/20 flex items-center justify-center text-xs">
                      A
                    </span>
                    <span>Langsung di HP / Offline</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Unduh file <code>index.html</code> lalu kirimkan via WhatsApp atau Bluetooth ke
                    HP staf. Buka dengan browser Chrome/Safari, lalu pilih menu{' '}
                    <strong>"Tambahkan ke Layar Utama" (Add to Home Screen)</strong>.
                  </p>
                  <div className="text-[11px] text-emerald-300 font-semibold pt-1">
                    ✓ Dapat dijalankan 100% tanpa internet
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-cyan-400 text-sm">
                    <span className="w-6 h-6 rounded-lg bg-cyan-500/20 flex items-center justify-center text-xs">
                      B
                    </span>
                    <span>GitHub Pages (Gratis)</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Buat repositori baru di GitHub (misal <code>sisa-fisik</code>), unggah file{' '}
                    <code>index.html</code>, lalu aktifkan GitHub Pages di menu Settings.
                  </p>
                  <div className="text-[11px] text-cyan-300 font-semibold pt-1">
                    ✓ Mendapat link online gratis (username.github.io/sisa-fisik)
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-purple-400 text-sm">
                    <span className="w-6 h-6 rounded-lg bg-purple-500/20 flex items-center justify-center text-xs">
                      C
                    </span>
                    <span>Netlify / Vercel Drop</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    Kunjungi <code>app.netlify.com/drop</code> dan tarik (drag and drop) folder yang
                    berisi file <code>index.html</code> ini. Dalam 5 detik, link HTTPS publik
                    langsung aktif.
                  </p>
                  <div className="text-[11px] text-purple-300 font-semibold pt-1">
                    ✓ Link instan dengan SSL HTTPS otomatis
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
